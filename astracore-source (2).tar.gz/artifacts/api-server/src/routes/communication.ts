import { Router } from "express";
import { requireAuth } from "../middlewares/auth";

const router = Router();

const DESTINATIONS: Record<string, { distanceKm: number; description: string }> = {
  Moon: { distanceKm: 384400, description: "Earth's natural satellite" },
  Mars: { distanceKm: 225000000, description: "The Red Planet" },
  Venus: { distanceKm: 100000000, description: "Earth's twin" },
  Jupiter: { distanceKm: 778500000, description: "The Gas Giant" },
  Saturn: { distanceKm: 1432000000, description: "The Ringed Giant" },
  "Deep Space": { distanceKm: 5000000000, description: "Beyond the Solar System" },
  "ISS (Low Earth Orbit)": { distanceKm: 408, description: "International Space Station" },
};

const SPEED_OF_LIGHT_KM_S = 299792.458;

router.post("/communication/simulate", requireAuth, async (req, res) => {
  const { destination, message } = req.body;
  if (!destination) {
    res.status(400).json({ error: "destination required" });
    return;
  }
  const dest = DESTINATIONS[destination];
  if (!dest) {
    res.status(400).json({ error: "Unknown destination" });
    return;
  }
  const oneWayDelaySeconds = dest.distanceKm / SPEED_OF_LIGHT_KM_S;
  const roundTripDelaySeconds = oneWayDelaySeconds * 2;
  const signalStrength = Math.max(5, Math.min(100, 100 - Math.log10(dest.distanceKm) * 10));
  const status: "excellent" | "good" | "degraded" | "critical" =
    signalStrength > 70 ? "excellent" : signalStrength > 50 ? "good" : signalStrength > 30 ? "degraded" : "critical";

  res.json({
    destination,
    distanceKm: dest.distanceKm,
    oneWayDelaySeconds: Math.round(oneWayDelaySeconds * 100) / 100,
    roundTripDelaySeconds: Math.round(roundTripDelaySeconds * 100) / 100,
    signalStrength: Math.round(signalStrength * 10) / 10,
    status,
    message: message ?? `Signal transmitted to ${destination}. Awaiting response.`,
  });
});

export default router;
