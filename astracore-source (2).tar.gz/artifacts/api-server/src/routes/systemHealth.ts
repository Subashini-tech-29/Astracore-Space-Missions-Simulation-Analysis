import { Router } from "express";
import { db, systemHealthTable } from "@workspace/db";
import { desc } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";

const router = Router();

router.get("/system-health", requireAuth, async (req, res) => {
  const [latest] = await db
    .select()
    .from(systemHealthTable)
    .orderBy(desc(systemHealthTable.timestamp))
    .limit(1);
  if (!latest) {
    const [inserted] = await db
      .insert(systemHealthTable)
      .values({
        fuelLevel: "87.5",
        temperature: "22.3",
        battery: "94.1",
        signalStrength: "78.6",
        oxygenLevel: "99.2",
        thrusterStatus: "nominal",
      })
      .returning();
    res.json(inserted);
    return;
  }
  res.json(latest);
});

router.get("/system-health/history", requireAuth, async (req, res) => {
  const rows = await db
    .select()
    .from(systemHealthTable)
    .orderBy(desc(systemHealthTable.timestamp))
    .limit(24);
  res.json(rows.reverse());
});

export default router;
