import { Router } from "express";
import { db, predictionsTable, missionsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";

const router = Router();

const RISK_FACTORS: Record<string, string[]> = {
  Mars: ["Radiation exposure during transit", "Dust storm probability 23%", "EDL complexity"],
  Moon: ["Low gravity operations", "Temperature extremes", "Micrometeorite risk"],
  Jupiter: ["Extreme radiation belts", "Long transit duration", "Communication delay 45-52 min"],
  Venus: ["Extreme atmospheric pressure", "Sulfuric acid clouds", "High temperature surface"],
  Saturn: ["Ring navigation hazard", "Titan atmospheric entry", "Long mission duration"],
  "Deep Space": ["Communication blackout risk", "Cosmic ray exposure", "Supply constraints"],
};

function computeRisk(prob: number): "low" | "medium" | "high" | "critical" {
  if (prob >= 80) return "low";
  if (prob >= 60) return "medium";
  if (prob >= 40) return "high";
  return "critical";
}

router.post("/ai/predict", requireAuth, async (req, res) => {
  const { missionId, destination, payload, launchDate } = req.body;
  if (!destination && !missionId) {
    res.status(400).json({ error: "missionId or destination required" });
    return;
  }

  let resolvedDestination = destination;
  let missionName: string | null = null;

  if (missionId) {
    const [mission] = await db
      .select()
      .from(missionsTable)
      .where(eq(missionsTable.id, parseInt(missionId)));
    if (mission) {
      resolvedDestination = mission.destination;
      missionName = mission.name;
    }
  }

  const baseProbability = Math.random() * 40 + 50;
  const riskLevel = computeRisk(baseProbability);
  const factors = RISK_FACTORS[resolvedDestination] ?? RISK_FACTORS["Deep Space"];
  const successProb = Math.round(baseProbability * 100) / 100;
  const confidence = Math.round((70 + Math.random() * 25) * 100) / 100;
  const recommendation =
    riskLevel === "low"
      ? "Mission is cleared for launch. All systems nominal."
      : riskLevel === "medium"
        ? "Proceed with caution. Address flagged risk factors before launch."
        : riskLevel === "high"
          ? "Launch window postponement recommended. Critical review required."
          : "Mission abort advised. Multiple critical risk factors detected.";

  const [prediction] = await db
    .insert(predictionsTable)
    .values({
      missionId: missionId ? parseInt(missionId) : null,
      missionName,
      successProbability: String(successProb),
      riskLevel,
      riskFactors: factors,
      recommendation,
      confidence: String(confidence),
    })
    .returning();

  if (missionId) {
    await db
      .update(missionsTable)
      .set({ successProbability: String(successProb) })
      .where(eq(missionsTable.id, parseInt(missionId)));
  }

  res.json(prediction);
});

router.get("/ai/predictions", requireAuth, async (req, res) => {
  const predictions = await db
    .select()
    .from(predictionsTable)
    .orderBy(desc(predictionsTable.createdAt))
    .limit(50);
  res.json(predictions);
});

export default router;
