import React, { useEffect } from "react";
import { Link, useLocation } from "wouter";
import { motion } from "framer-motion";
import { 
  Rocket, 
  LayoutDashboard, 
  Activity, 
  AlertTriangle, 
  BarChart3, 
  BrainCircuit, 
  Radio, 
  Newspaper, 
  Users,
  LogOut,
  Menu
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useGetMe } from "@workspace/api-client-react";
import { clearAuthToken } from "@/lib/auth";
import { Button } from "@/components/ui/button";

const navItems = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/missions", label: "Missions", icon: Rocket },
  { href: "/system-health", label: "System Health", icon: Activity },
  { href: "/alerts", label: "Alerts", icon: AlertTriangle },
  { href: "/analytics", label: "Analytics", icon: BarChart3 },
  { href: "/ai-predictions", label: "AI Predictions", icon: BrainCircuit },
  { href: "/communication", label: "Communication", icon: Radio },
  { href: "/news", label: "Space News", icon: Newspaper },
];

function ParticleBackground() {
  return (
    <div className="fixed inset-0 z-[-1] overflow-hidden pointer-events-none">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-900/20 via-background to-background"></div>
      {Array.from({ length: 50 }).map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-1 h-1 bg-white rounded-full opacity-50"
          initial={{
            x: Math.random() * window.innerWidth,
            y: Math.random() * window.innerHeight,
            scale: Math.random() * 0.5 + 0.5,
          }}
          animate={{
            y: [null, Math.random() * -100 - 50],
            opacity: [0.5, 1, 0.5],
          }}
          transition={{
            duration: Math.random() * 10 + 10,
            repeat: Infinity,
            ease: "linear",
          }}
        />
      ))}
    </div>
  );
}

export function Shell({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();
  const { data: user, error, isError } = useGetMe();

  useEffect(() => {
    if (isError && (error as any)?.status === 401) {
      clearAuthToken();
      setLocation("/");
    }
  }, [isError, error, setLocation]);

  const handleLogout = () => {
    clearAuthToken();
    setLocation("/");
  };

  const adminNavItems = user?.role === "admin" 
    ? [...navItems, { href: "/users", label: "Users", icon: Users }]
    : navItems;

  return (
    <div className="min-h-screen bg-background text-foreground flex overflow-hidden">
      <ParticleBackground />
      
      {/* Sidebar */}
      <motion.aside 
        initial={{ x: -250 }}
        animate={{ x: 0 }}
        className="w-64 border-r border-border glass-panel flex-shrink-0 flex flex-col hidden md:flex"
      >
        <div className="h-16 flex items-center px-6 border-b border-border">
          <Rocket className="w-6 h-6 text-primary mr-2" />
          <span className="font-bold text-xl neon-text tracking-wider">ASTRACORE</span>
        </div>
        
        <nav className="flex-1 py-6 px-3 space-y-1 overflow-y-auto">
          {adminNavItems.map((item) => {
            const isActive = location.startsWith(item.href);
            return (
              <Link 
                key={item.href} 
                href={item.href}
                className={cn(
                  "flex items-center px-3 py-2.5 rounded-md transition-all duration-200 group relative overflow-hidden",
                  isActive ? "text-primary bg-primary/10" : "text-muted-foreground hover:text-foreground hover:bg-white/5"
                )}
              >
                {isActive && (
                  <motion.div 
                    layoutId="activeTab" 
                    className="absolute left-0 top-0 bottom-0 w-1 bg-primary neon-border"
                  />
                )}
                <item.icon className={cn("w-5 h-5 mr-3", isActive ? "text-primary" : "")} />
                <span className="font-medium">{item.label}</span>
              </Link>
            );
          })}
        </nav>
        
        <div className="p-4 border-t border-border mt-auto">
          <div className="flex items-center justify-between">
            <div className="flex flex-col">
              <span className="text-sm font-medium">{user?.username}</span>
              <span className="text-xs text-muted-foreground capitalize">{user?.role}</span>
            </div>
            <Button variant="ghost" size="icon" onClick={handleLogout} className="text-muted-foreground hover:text-destructive">
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </motion.aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <header className="h-16 border-b border-border glass-panel flex items-center justify-between px-6 md:hidden">
          <div className="flex items-center">
            <Rocket className="w-6 h-6 text-primary mr-2" />
            <span className="font-bold text-xl neon-text">ASTRACORE</span>
          </div>
          <Button variant="ghost" size="icon">
            <Menu className="w-5 h-5" />
          </Button>
        </header>
        
        <div className="flex-1 overflow-y-auto p-4 md:p-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="max-w-7xl mx-auto h-full"
          >
            {children}
          </motion.div>
        </div>
      </main>
    </div>
  );
}
