import { pgTable, serial, text, timestamp, integer, numeric, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const missionStatusEnum = pgEnum("mission_status", [
  "planning", "active", "completed", "failed", "aborted"
]);

export const missionsTable = pgTable("missions", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  destination: text("destination").notNull(),
  launchDate: timestamp("launch_date").notNull(),
  payload: text("payload").notNull(),
  status: missionStatusEnum("status").notNull().default("planning"),
  description: text("description"),
  successProbability: numeric("success_probability", { precision: 5, scale: 2 }),
  userId: integer("user_id").notNull().references(() => usersTable.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertMissionSchema = createInsertSchema(missionsTable).omit({ id: true, createdAt: true });
export type InsertMission = z.infer<typeof insertMissionSchema>;
export type Mission = typeof missionsTable.$inferSelect;
