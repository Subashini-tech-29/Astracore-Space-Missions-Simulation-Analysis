import { Router } from "express";
import { db, missionsTable } from "@workspace/db";
import { eq, desc, ilike, and, SQL } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";

const router = Router();

router.get("/missions", requireAuth, async (req, res) => {
  const { status, destination, search } = req.query as Record<string, string>;
  const conditions: SQL[] = [];
  if (status) conditions.push(eq(missionsTable.status, status as never));
  if (destination) conditions.push(ilike(missionsTable.destination, `%${destination}%`));
  if (search) conditions.push(ilike(missionsTable.name, `%${search}%`));
  const missions = await db
    .select()
    .from(missionsTable)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(desc(missionsTable.createdAt));
  res.json(missions);
});

router.post("/missions", requireAuth, async (req, res) => {
  const { name, destination, launchDate, payload, status, description, successProbability } = req.body;
  if (!name || !destination || !launchDate || !payload) {
    res.status(400).json({ error: "name, destination, launchDate, payload required" });
    return;
  }
  const [mission] = await db
    .insert(missionsTable)
    .values({
      name,
      destination,
      launchDate: new Date(launchDate),
      payload,
      status: status ?? "planning",
      description,
      successProbability,
      userId: req.user!.userId,
    })
    .returning();
  res.status(201).json(mission);
});

router.get("/missions/:id", requireAuth, async (req, res) => {
  const id = parseInt(req.params.id);
  const [mission] = await db.select().from(missionsTable).where(eq(missionsTable.id, id));
  if (!mission) {
    res.status(404).json({ error: "Mission not found" });
    return;
  }
  res.json(mission);
});

router.patch("/missions/:id", requireAuth, async (req, res) => {
  const id = parseInt(req.params.id);
  const { name, destination, launchDate, payload, status, description, successProbability } = req.body;
  const updates: Partial<typeof missionsTable.$inferInsert> = {};
  if (name) updates.name = name;
  if (destination) updates.destination = destination;
  if (launchDate) updates.launchDate = new Date(launchDate);
  if (payload) updates.payload = payload;
  if (status) updates.status = status;
  if (description !== undefined) updates.description = description;
  if (successProbability !== undefined) updates.successProbability = successProbability;
  const [mission] = await db
    .update(missionsTable)
    .set(updates)
    .where(eq(missionsTable.id, id))
    .returning();
  if (!mission) {
    res.status(404).json({ error: "Mission not found" });
    return;
  }
  res.json(mission);
});

router.delete("/missions/:id", requireAuth, async (req, res) => {
  const id = parseInt(req.params.id);
  const [deleted] = await db
    .delete(missionsTable)
    .where(eq(missionsTable.id, id))
    .returning();
  if (!deleted) {
    res.status(404).json({ error: "Mission not found" });
    return;
  }
  res.json({ deleted: true });
});

export default router;
