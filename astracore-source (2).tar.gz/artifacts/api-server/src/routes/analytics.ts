import { Router } from "express";
import { db, missionsTable, alertsTable, usersTable, systemHealthTable } from "@workspace/db";
import { eq, count, avg, sql } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";

const router = Router();

router.get("/analytics/summary", requireAuth, async (req, res) => {
  const [missionStats] = await db.select({ total: count() }).from(missionsTable);
  const [activeStats] = await db
    .select({ active: count() })
    .from(missionsTable)
    .where(eq(missionsTable.status, "active"));
  const [completedStats] = await db
    .select({ completed: count() })
    .from(missionsTable)
    .where(eq(missionsTable.status, "completed"));
  const [alertStats] = await db.select({ total: count() }).from(alertsTable);
  const [criticalStats] = await db
    .select({ critical: count() })
    .from(alertsTable)
    .where(eq(alertsTable.severity, "critical"));
  const [userStats] = await db.select({ total: count() }).from(usersTable);
  const [healthStats] = await db
    .select({ avgHealth: avg(systemHealthTable.fuelLevel) })
    .from(systemHealthTable);

  const total = Number(missionStats?.total ?? 0);
  const completed = Number(completedStats?.completed ?? 0);
  const successRate = total > 0 ? Math.round((completed / total) * 100) : 0;

  res.json({
    totalMissions: total,
    activeMissions: Number(activeStats?.active ?? 0),
    successRate,
    totalAlerts: Number(alertStats?.total ?? 0),
    criticalAlerts: Number(criticalStats?.critical ?? 0),
    systemHealthScore: Math.round(Number(healthStats?.avgHealth ?? 85)),
    totalUsers: Number(userStats?.total ?? 0),
  });
});

router.get("/analytics/missions-by-status", requireAuth, async (req, res) => {
  const rows = await db
    .select({ status: missionsTable.status, count: count() })
    .from(missionsTable)
    .groupBy(missionsTable.status);
  res.json(rows.map((r) => ({ status: r.status, count: Number(r.count) })));
});

router.get("/analytics/missions-by-destination", requireAuth, async (req, res) => {
  const rows = await db
    .select({ destination: missionsTable.destination, count: count() })
    .from(missionsTable)
    .groupBy(missionsTable.destination)
    .orderBy(sql`count(*) desc`)
    .limit(10);
  res.json(rows.map((r) => ({ destination: r.destination, count: Number(r.count) })));
});

router.get("/analytics/alerts-timeline", requireAuth, async (req, res) => {
  const rows = await db.execute(sql`
    SELECT DATE_TRUNC('day', created_at) AS date,
           severity,
           COUNT(*) AS count
    FROM alerts
    GROUP BY DATE_TRUNC('day', created_at), severity
    ORDER BY date DESC
    LIMIT 30
  `);
  res.json(
    (rows.rows as Array<{ date: string; severity: string; count: string }>).map((r) => ({
      date: r.date,
      severity: r.severity,
      count: Number(r.count),
    }))
  );
});

export default router;
