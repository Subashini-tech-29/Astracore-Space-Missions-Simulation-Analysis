import { pgTable, serial, text, timestamp, integer, numeric, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { missionsTable } from "./missions";

export const riskLevelEnum = pgEnum("risk_level", ["low", "medium", "high", "critical"]);

export const predictionsTable = pgTable("predictions", {
  id: serial("id").primaryKey(),
  missionId: integer("mission_id").references(() => missionsTable.id),
  missionName: text("mission_name"),
  successProbability: numeric("success_probability", { precision: 5, scale: 2 }).notNull(),
  riskLevel: riskLevelEnum("risk_level").notNull(),
  riskFactors: text("risk_factors").array().notNull(),
  recommendation: text("recommendation").notNull(),
  confidence: numeric("confidence", { precision: 5, scale: 2 }).notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertPredictionSchema = createInsertSchema(predictionsTable).omit({ id: true, createdAt: true });
export type InsertPrediction = z.infer<typeof insertPredictionSchema>;
export type Prediction = typeof predictionsTable.$inferSelect;
