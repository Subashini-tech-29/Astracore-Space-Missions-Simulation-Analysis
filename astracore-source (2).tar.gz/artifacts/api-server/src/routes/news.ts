import { Router } from "express";
import { requireAuth } from "../middlewares/auth";

const router = Router();

const MOCK_NEWS = [
  {
    id: 1,
    title: "NASA Artemis III Moon Landing Set for Late 2026",
    summary: "NASA confirms the crewed Moon landing mission will target the lunar south pole, with SpaceX Starship serving as the lander.",
    source: "NASA",
    url: "https://nasa.gov",
    imageUrl: "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=800",
    publishedAt: new Date(Date.now() - 1 * 3600000).toISOString(),
    category: "nasa",
  },
  {
    id: 2,
    title: "ISRO Chandrayaan-4 Mission Receives Final Approval",
    summary: "India's space agency ISRO announces final approval for Chandrayaan-4 lunar sample return mission planned for 2027.",
    source: "ISRO",
    url: "https://isro.gov.in",
    imageUrl: "https://images.unsplash.com/photo-1614728894747-a83421e2b9c9?w=800",
    publishedAt: new Date(Date.now() - 3 * 3600000).toISOString(),
    category: "isro",
  },
  {
    id: 3,
    title: "SpaceX Starship Completes 10th Integrated Test Flight",
    summary: "SpaceX successfully completes the 10th integrated test flight of Starship, achieving full booster catch and controlled splashdown.",
    source: "SpaceX",
    url: "https://spacex.com",
    imageUrl: "https://images.unsplash.com/photo-1569025690938-a00729c9e1f9?w=800",
    publishedAt: new Date(Date.now() - 6 * 3600000).toISOString(),
    category: "spacex",
  },
  {
    id: 4,
    title: "ESA Mars Sample Return Mission Enters Development Phase",
    summary: "The European Space Agency announces the Mars Sample Return mission has entered full development phase, targeting 2035 sample retrieval.",
    source: "ESA",
    url: "https://esa.int",
    imageUrl: "https://images.unsplash.com/photo-1614728894747-a83421e2b9c9?w=800",
    publishedAt: new Date(Date.now() - 12 * 3600000).toISOString(),
    category: "esa",
  },
  {
    id: 5,
    title: "James Webb Telescope Discovers Water Vapor on Exoplanet",
    summary: "JWST observations confirm water vapor in the atmosphere of exoplanet K2-18b, a potential candidate for habitability studies.",
    source: "NASA",
    url: "https://nasa.gov",
    imageUrl: "https://images.unsplash.com/photo-1462331940025-496dfbfc7564?w=800",
    publishedAt: new Date(Date.now() - 24 * 3600000).toISOString(),
    category: "general",
  },
  {
    id: 6,
    title: "China's Tianwen-3 Mars Mission Launches Successfully",
    summary: "China successfully launches Tianwen-3, its second Mars mission, aiming to return the first Martian soil samples to Earth by 2031.",
    source: "CNSA",
    url: "https://cnsa.gov.cn",
    imageUrl: "https://images.unsplash.com/photo-1545156521-77bd85671d30?w=800",
    publishedAt: new Date(Date.now() - 48 * 3600000).toISOString(),
    category: "general",
  },
];

router.get("/news", requireAuth, async (req, res) => {
  const { category } = req.query as { category?: string };
  const filtered = category
    ? MOCK_NEWS.filter((n) => n.category === category)
    : MOCK_NEWS;
  res.json(filtered);
});

export default router;
