import { pgTable, serial, timestamp, numeric, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const thrusterStatusEnum = pgEnum("thruster_status", ["nominal", "degraded", "critical", "offline"]);

export const systemHealthTable = pgTable("system_health", {
  id: serial("id").primaryKey(),
  fuelLevel: numeric("fuel_level", { precision: 5, scale: 2 }).notNull(),
  temperature: numeric("temperature", { precision: 6, scale: 2 }).notNull(),
  battery: numeric("battery", { precision: 5, scale: 2 }).notNull(),
  signalStrength: numeric("signal_strength", { precision: 5, scale: 2 }).notNull(),
  oxygenLevel: numeric("oxygen_level", { precision: 5, scale: 2 }).notNull(),
  thrusterStatus: thrusterStatusEnum("thruster_status").notNull().default("nominal"),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const insertSystemHealthSchema = createInsertSchema(systemHealthTable).omit({ id: true, timestamp: true });
export type InsertSystemHealth = z.infer<typeof insertSystemHealthSchema>;
export type SystemHealth = typeof systemHealthTable.$inferSelect;
