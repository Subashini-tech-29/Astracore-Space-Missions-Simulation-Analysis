import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import missionsRouter from "./missions";
import alertsRouter from "./alerts";
import analyticsRouter from "./analytics";
import systemHealthRouter from "./systemHealth";
import predictionsRouter from "./predictions";
import newsRouter from "./news";
import communicationRouter from "./communication";
import usersRouter from "./users";
import telemetryRouter from "./telemetry";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(missionsRouter);
router.use(alertsRouter);
router.use(analyticsRouter);
router.use(systemHealthRouter);
router.use(predictionsRouter);
router.use(newsRouter);
router.use(communicationRouter);
router.use(usersRouter);
router.use(telemetryRouter);

export default router;
