import { setAuthTokenGetter } from "@workspace/api-client-react/custom-fetch";

export const AUTH_TOKEN_KEY = "astracore_token";

export function getAuthToken(): string | null {
  return localStorage.getItem(AUTH_TOKEN_KEY);
}

export function setAuthToken(token: string): void {
  localStorage.setItem(AUTH_TOKEN_KEY, token);
}

export function clearAuthToken(): void {
  localStorage.removeItem(AUTH_TOKEN_KEY);
}

// Register the getter with the API client so it attaches the token to every request
setAuthTokenGetter(getAuthToken);
