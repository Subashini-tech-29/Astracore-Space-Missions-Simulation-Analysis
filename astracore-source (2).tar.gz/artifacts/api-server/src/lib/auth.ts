import jwt from "jsonwebtoken";

const JWT_SECRET = process.env.SESSION_SECRET ?? "astracore-secret-key";

export interface JwtPayload {
  userId: number;
  username: string;
  role: "admin" | "user";
}

export function signToken(payload: JwtPayload): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: "7d" });
}

export function verifyToken(token: string): JwtPayload {
  return jwt.verify(token, JWT_SECRET) as JwtPayload;
}
