import { Router } from "express";
import { db, alertsTable } from "@workspace/db";
import { eq, desc, and, SQL } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";

const router = Router();

router.get("/alerts", requireAuth, async (req, res) => {
  const { severity, missionId, acknowledged } = req.query as Record<string, string>;
  const conditions: SQL[] = [];
  if (severity) conditions.push(eq(alertsTable.severity, severity as never));
  if (missionId) conditions.push(eq(alertsTable.missionId, parseInt(missionId)));
  if (acknowledged !== undefined) conditions.push(eq(alertsTable.acknowledged, acknowledged === "true"));
  const alerts = await db
    .select()
    .from(alertsTable)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(desc(alertsTable.createdAt));
  res.json(alerts);
});

router.post("/alerts", requireAuth, async (req, res) => {
  const { type, severity, message, missionId } = req.body;
  if (!type || !severity || !message) {
    res.status(400).json({ error: "type, severity, message required" });
    return;
  }
  const [alert] = await db
    .insert(alertsTable)
    .values({ type, severity, message, missionId: missionId ?? null })
    .returning();
  res.status(201).json(alert);
});

router.post("/alerts/:id/acknowledge", requireAuth, async (req, res) => {
  const id = parseInt(req.params.id);
  const [alert] = await db
    .update(alertsTable)
    .set({ acknowledged: true })
    .where(eq(alertsTable.id, id))
    .returning();
  if (!alert) {
    res.status(404).json({ error: "Alert not found" });
    return;
  }
  res.json(alert);
});

export default router;
