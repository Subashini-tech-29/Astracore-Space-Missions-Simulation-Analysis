import { Router } from "express";
import { requireAuth } from "../middlewares/auth";

const router = Router();

interface TelemetryState {
  fuelLevel: number;
  temperature: number;
  battery: number;
  signalStrength: number;
  oxygenLevel: number;
  thrusterStatus: string;
  altitude: number;
  velocity: number;
  distanceFromEarth: number;
  radiationLevel: number;
}

let state: TelemetryState = {
  fuelLevel: 87.5,
  temperature: 22.3,
  battery: 94.1,
  signalStrength: 78.6,
  oxygenLevel: 99.2,
  thrusterStatus: "nominal",
  altitude: 408,
  velocity: 27600,
  distanceFromEarth: 384400,
  radiationLevel: 12.4,
};

function clamp(val: number, min: number, max: number) {
  return Math.min(max, Math.max(min, val));
}

function drift(val: number, delta: number, min: number, max: number) {
  return clamp(val + (Math.random() - 0.5) * delta, min, max);
}

function nextState(): TelemetryState {
  state = {
    fuelLevel: drift(state.fuelLevel, 0.3, 0, 100),
    temperature: drift(state.temperature, 0.4, 18, 35),
    battery: drift(state.battery, 0.2, 70, 100),
    signalStrength: drift(state.signalStrength, 1.5, 30, 100),
    oxygenLevel: drift(state.oxygenLevel, 0.1, 95, 100),
    thrusterStatus: Math.random() > 0.97 ? "warning" : "nominal",
    altitude: drift(state.altitude, 1.2, 380, 440),
    velocity: drift(state.velocity, 20, 27400, 27800),
    distanceFromEarth: state.distanceFromEarth + (Math.random() - 0.3) * 50,
    radiationLevel: drift(state.radiationLevel, 0.5, 5, 40),
  };
  return state;
}

router.get("/telemetry/stream", requireAuth, (req, res) => {
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");
  res.flushHeaders();

  const send = () => {
    const data = { ...nextState(), timestamp: new Date().toISOString() };
    res.write(`data: ${JSON.stringify(data)}\n\n`);
  };

  send();
  const interval = setInterval(send, 2000);

  req.on("close", () => clearInterval(interval));
});

export default router;
