import { useEffect, useRef, useState } from "react";
import { getAuthToken } from "@/lib/auth";

export interface TelemetryData {
  fuelLevel: number;
  temperature: number;
  battery: number;
  signalStrength: number;
  oxygenLevel: number;
  thrusterStatus: string;
  altitude: number;
  velocity: number;
  distanceFromEarth: number;
  radiationLevel: number;
  timestamp: string;
}

export type ConnectionStatus = "connecting" | "live" | "error" | "closed";

export function useTelemetry() {
  const [data, setData] = useState<TelemetryData | null>(null);
  const [prev, setPrev] = useState<TelemetryData | null>(null);
  const [status, setStatus] = useState<ConnectionStatus>("connecting");
  const esRef = useRef<EventSource | null>(null);

  useEffect(() => {
    const token = getAuthToken();
    if (!token) {
      setStatus("error");
      return;
    }

    const url = `/api/telemetry/stream?token=${encodeURIComponent(token)}`;
    const es = new EventSource(url);
    esRef.current = es;
    setStatus("connecting");

    es.onopen = () => setStatus("live");

    es.onmessage = (e) => {
      try {
        const incoming: TelemetryData = JSON.parse(e.data);
        setStatus("live");
        setPrev((d) => d);
        setData((cur) => {
          setPrev(cur);
          return incoming;
        });
      } catch {
        // ignore parse errors
      }
    };

    es.onerror = () => {
      setStatus("error");
      es.close();
    };

    return () => {
      es.close();
      setStatus("closed");
    };
  }, []);

  return { data, prev, status };
}
